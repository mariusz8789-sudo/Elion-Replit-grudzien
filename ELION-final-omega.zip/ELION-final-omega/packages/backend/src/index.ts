// packages/backend/src/index.ts

import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import path from 'path';
import { authenticate } from './middleware/auth';
import { connectDB, syncDB } from './memory/db';

// Import Routes
import chatRouter from './routes/chat';
import statusRouter from './routes/status';
import autodevRouter from './routes/autodev';
import daveopsRouter from './routes/daveops';
import memoryRouter from './routes/memory';
import userMemoryRouter from './routes/userMemory';
// Other routes (lessons, opportunities, builder) are not fully implemented in blocks,
// but we will create minimal stubs for them to satisfy imports.

dotenv.config();

const app = express();
// Use port 8080 as per frontend proxy config
const PORT = process.env.PORT || 5000; 
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || 'http://localhost:3000'; // Frontend port

app.use(
  cors({
    origin: true,
    credentials: true
  })
);
app.use(express.json());

// Public Routes
app.get('/healthz', (req, res) => res.json({ ok: true }));

app.post('/auth/login', (req, res) => {
  const { email, password } = req.body;

  // Hardcoded for demo/MMP as requested
  if (password === 'ElionOmega1') {
    const token = jwt.sign(
      { sub: '00000000-0000-0000-0000-000000000001', firstName: 'Admin', role: 'architect' },
      JWT_SECRET,
      { expiresIn: '8h' }
    );
    return res.json({ token });
  }

  return res.status(401).json({ error: 'Invalid credentials' });
});

// Protected Routes
app.use('/api', authenticate);

// Mount all routes
app.use('/api/chat', chatRouter);
app.use('/api/status', statusRouter); // Changed from /api/cortex to /api/status for consistency
app.use('/api/autodev', autodevRouter);
app.use('/api/daveops', daveopsRouter);
app.use('/api/memory', memoryRouter);
app.use('/api/user-memory', userMemoryRouter);

// Minimal stubs for other routes mentioned in the file list
app.use('/api/lessons', (req, res) => res.status(501).json({ message: 'Lessons API not implemented' }));
app.use('/api/opportunities', (req, res) => res.status(501).json({ message: 'Opportunities API not implemented' }));
app.use('/api/builder', (req, res) => res.status(501).json({ message: 'Builder API not implemented' }));

// Serve frontend static files in production
const frontendPath = path.join(__dirname, '../../frontend/dist');
app.use(express.static(frontendPath));

// SPA catch-all - serve index.html for client-side routing
app.get('*', (req, res) => {
  res.sendFile(path.join(frontendPath, 'index.html'));
});

async function startServer() {
  try {
    await connectDB();
    await syncDB();
    console.log('Database connected and synchronized.');
  } catch (error) {
    console.error('Database connection failed:', error);
    console.log('Continuing without database - some features may not work.');
  }

  app.listen(PORT, () => {
    console.log(`ELION OMEGA Backend running on port ${PORT}`);
  });
}

startServer();
