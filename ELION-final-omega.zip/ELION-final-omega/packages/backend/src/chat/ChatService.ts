// packages/backend/src/chat/ChatService.ts

import { elionAgent } from '../agent/core';
import { 
  ConversationThread, 
  Message, 
  ProjectSession, 
  MemoryEntry, 
  toThreadInterface, 
  toMessageInterface 
} from '../models/chat';
import { Op, literal } from 'sequelize';

// Default project ID for simplicity, matches the user ID used in auth
const DEFAULT_PROJECT_ID = '00000000-0000-0000-0000-000000000001';

export class ChatService {
  
  // --- THREADS (SESSIONS) ---

  async getThreads(projectId: string = DEFAULT_PROJECT_ID): Promise<ConversationThread[]> {
    const sessions = await ProjectSession.findAll({
      where: { project_id: projectId },
      order: [['updated_at', 'DESC']],
      // Include message count for display
      attributes: {
        include: [
          [
            literal(`(
              SELECT COUNT(*)
              FROM memory_entries AS me
              WHERE
                me.session_id = "ProjectSession".id
                AND me.entry_type = 'chat_log'
            )`),
            'messageCount',
          ],
        ],
      },
    });

    return sessions.map(session => ({
      ...toThreadInterface(session),
      messageCount: session.get('messageCount') as number,
    }));
  }

  async createThread(title: string = 'New Chat', projectId: string = DEFAULT_PROJECT_ID): Promise<ConversationThread> {
    const session = await ProjectSession.create({
      project_id: projectId,
      title: title,
      is_favorite: false,
    });
    return { ...toThreadInterface(session), messageCount: 0 };
  }

  async updateThread(id: string, updates: Partial<ConversationThread>): Promise<ConversationThread | undefined> {
    const session = await ProjectSession.findByPk(id);
    if (!session) return undefined;

    const dbUpdates: any = {};
    if (updates.title !== undefined) dbUpdates.title = updates.title;
    if (updates.isFavorite !== undefined) dbUpdates.is_favorite = updates.isFavorite;

    await session.update(dbUpdates);
    return { ...toThreadInterface(session), messageCount: 0 }; // messageCount is not updated here
  }

  async deleteThread(id: string): Promise<boolean> {
    const deletedCount = await ProjectSession.destroy({ where: { id } });
    return deletedCount > 0;
  }

  // --- MESSAGES ---

  async getMessages(threadId: string): Promise<Message[]> {
    const entries = await MemoryEntry.findAll({
      where: { 
        session_id: threadId,
        entry_type: 'chat_log',
      },
      order: [['created_at', 'ASC']],
    });
    return entries.map(toMessageInterface);
  }

  /**
   * Handles sending a message, saving it, and generating an assistant response.
   */
  async sendMessage(threadId: string, content: string, projectId: string = DEFAULT_PROJECT_ID): Promise<{ userMessage: Message, assistantMessage: Message }> {
    // 1. Save user message
    const userEntry = await MemoryEntry.create({
      session_id: threadId,
      project_id: projectId,
      entry_type: 'chat_log',
      role: 'user',
      content: content,
    });
    const userMessage = toMessageInterface(userEntry);

    // 2. Get full history for context
    const history = await this.getMessages(threadId);
    const llmMessages = [
      { role: 'system', content: 'You are ELION OMEGA, an AI system repair architect. Your goal is to be helpful and concise.' },
      ...history.map(msg => ({ role: msg.role, content: msg.content }))
    ];

    // 3. Generate LLM response using the ElionAgent
    const llmResponse = await elionAgent.run(content, projectId, 'default-user'); // userId is not available here, using default

    // 4. Save assistant message
    const assistantEntry = await MemoryEntry.create({
      session_id: threadId,
      project_id: projectId,
      entry_type: 'chat_log',
      role: 'assistant',
      content: llmResponse,
    });
    const assistantMessage = toMessageInterface(assistantEntry);

    // 5. Update thread timestamp
    await ProjectSession.update({ updated_at: new Date() }, { where: { id: threadId } });

    return { userMessage, assistantMessage };
  }
}

export const chatService = new ChatService();
