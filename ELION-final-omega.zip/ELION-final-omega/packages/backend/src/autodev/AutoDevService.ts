// packages/backend/src/autodev/AutoDevService.ts

import { LLMMessage, generateLLMResponse } from '../services/llm';

export interface AutoDevTask {
  taskId: string;
  status: 'PLANNING' | 'CODING' | 'TESTING' | 'COMPLETED' | 'FAILED';
  progress: number; // 0-100
  summary: string;
  logs: string[];
}

export class AutoDevService {
  private static instance: AutoDevService;
  private tasks: Map<string, AutoDevTask> = new Map();

  public static getInstance(): AutoDevService {
    if (!AutoDevService.instance) {
      AutoDevService.instance = new AutoDevService();
    }
    return AutoDevService.instance;
  }

  /**
   * Simulates starting an AutoDev task with a full pipeline.
   */
  async startTask(projectId: string, goal: string): Promise<AutoDevTask> {
    const taskId = `autodev-task-${Date.now()}`;
    const task: AutoDevTask = {
      taskId,
      status: 'PLANNING',
      progress: 5,
      summary: `Starting AutoDev pipeline for goal: "${goal}"`,
      logs: [`[${new Date().toISOString()}] Task created. Starting planning phase.`],
    };
    this.tasks.set(taskId, task);

    // Start the async pipeline
    this.runPipeline(taskId, projectId, goal);

    return task;
  }

  private async runPipeline(taskId: string, projectId: string, goal: string) {
    const task = this.tasks.get(taskId);
    if (!task) return;

    try {
      // --- 1. PLANNING ---
      task.logs.push(`[${new Date().toISOString()}] Calling LLM for detailed plan...`);
      const plan = await this.generatePlan(goal);
      task.summary = `Plan generated: ${plan.substring(0, 50)}...`;
      task.logs.push(`[${new Date().toISOString()}] Plan: ${plan}`);
      task.status = 'CODING';
      task.progress = 20;

      // --- 2. CODING ---
      task.logs.push(`[${new Date().toISOString()}] Starting code generation...`);
      await new Promise(resolve => setTimeout(resolve, 3000)); // Simulate coding time
      task.logs.push(`[${new Date().toISOString()}] Code generated for 3 files.`);
      task.progress = 60;

      // --- 3. TESTING ---
      task.status = 'TESTING';
      task.logs.push(`[${new Date().toISOString()}] Running automated tests...`);
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate testing time
      task.logs.push(`[${new Date().toISOString()}] Tests passed successfully.`);
      task.progress = 85;

      // --- 4. COMPLETION ---
      task.status = 'COMPLETED';
      task.summary = `Development for "${goal}" completed successfully.`;
      task.logs.push(`[${new Date().toISOString()}] Pipeline finished. Ready for review/deployment.`);
      task.progress = 100;

    } catch (error: any) {
      task.status = 'FAILED';
      task.summary = `Pipeline failed: ${error.message}`;
      task.logs.push(`[${new Date().toISOString()}] ERROR: ${error.message}`);
      task.progress = 100;
    }
  }

  private async generatePlan(goal: string): Promise<string> {
    const messages: LLMMessage[] = [
      { role: 'system', content: 'You are a planning AI. Given a development goal, provide a concise, step-by-step plan to achieve it. Respond only with the plan.' },
      { role: 'user', content: `Development Goal: ${goal}` }
    ];
    
    const response = await generateLLMResponse(messages, 0.5);
    return response.content || "Minimal plan: Analyze, Code, Test, Deploy.";
  }

  /**
   * Retrieves the status and logs of an AutoDev task.
   */
  getTaskStatus(taskId: string): AutoDevTask | undefined {
    return this.tasks.get(taskId);
  }
}

export const autoDevService = AutoDevService.getInstance();
