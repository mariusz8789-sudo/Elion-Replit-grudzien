// packages/backend/src/builder/BuilderService.ts

export interface BuilderTask {
  taskId: string;
  status: 'PENDING' | 'BUILDING' | 'COMPLETED' | 'FAILED';
  output: string;
}

export class BuilderService {
  private static instance: BuilderService;
  private tasks: Map<string, BuilderTask> = new Map();

  public static getInstance(): BuilderService {
    if (!BuilderService.instance) {
      BuilderService.instance = new BuilderService();
    }
    return BuilderService.instance;
  }

  /**
   * Simulates starting a project build.
   */
  async startBuild(projectId: string, target: string): Promise<BuilderTask> {
    const taskId = `builder-task-${Date.now()}`;
    const task: BuilderTask = {
      taskId,
      status: 'BUILDING',
      output: `Starting build for project ${projectId} targeting ${target}...`,
    };
    this.tasks.set(taskId, task);

    // Simulate async process
    setTimeout(() => {
      const currentTask = this.tasks.get(taskId);
      if (currentTask) {
        currentTask.status = 'COMPLETED';
        currentTask.output += `\nBuild completed successfully. Artifacts ready for deployment.`;
      }
    }, 4000);

    return task;
  }

  /**
   * Retrieves the status of a Builder task.
   */
  getTaskStatus(taskId: string): BuilderTask | undefined {
    return this.tasks.get(taskId);
  }
}

export const builderService = BuilderService.getInstance();
