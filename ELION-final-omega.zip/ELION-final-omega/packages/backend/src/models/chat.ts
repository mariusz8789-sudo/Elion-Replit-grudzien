// packages/backend/src/models/chat.ts

import { ProjectSession, MemoryEntry } from '../memory/db';
import { Op } from 'sequelize';

// --- Interface Definitions (Based on Sequelize Models) ---

export interface Message {
  id: string;
  threadId: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  createdAt: number;
  metadata?: {
    isBookmarked?: boolean;
    rating?: 'up' | 'down';
    [key: string]: any;
  };
}

export interface ConversationThread {
  id: string;
  projectId?: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  isFavorite: boolean;
  hasFiles: boolean; // Not directly supported by minimal schema, but kept for interface consistency
  messageCount: number; // Will be calculated or fetched separately
}

// --- ChatStore is now deprecated, logic moves to ChatService ---
// We keep the interfaces for frontend compatibility.

// Helper function to convert Sequelize model instance to the required interface
const toThreadInterface = (session: any): ConversationThread => ({
  id: session.get('id') as string,
  projectId: session.get('project_id') as string | undefined,
  title: session.get('title') as string,
  createdAt: new Date(session.get('created_at') as string).getTime(),
  updatedAt: new Date(session.get('updated_at') as string).getTime(),
  isFavorite: session.get('is_favorite') as boolean,
  hasFiles: false, // Placeholder
  messageCount: 0, // Placeholder, will be fetched by ChatService
});

const toMessageInterface = (entry: any): Message => ({
  id: entry.get('id') as string,
  threadId: entry.get('session_id') as string,
  role: entry.get('role') as 'user' | 'assistant' | 'system',
  content: entry.get('content') as string,
  createdAt: new Date(entry.get('created_at') as string).getTime(),
  metadata: entry.get('metadata') as any,
});

export { toThreadInterface, toMessageInterface, ProjectSession, MemoryEntry };
