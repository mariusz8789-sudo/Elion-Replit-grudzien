// packages/backend/src/memory/UserMemoryService.ts

import { UserMemory as UserMemoryModel } from './db';
import { Op } from 'sequelize';

export interface UserMemory {
  id: string;
  userId: string;
  key: string;
  value: string;
  createdAt: Date;
  updatedAt: Date;
}

export class UserMemoryService {
  private static instance: UserMemoryService;

  public static getInstance(): UserMemoryService {
    if (!UserMemoryService.instance) {
      UserMemoryService.instance = new UserMemoryService();
    }
    return UserMemoryService.instance;
  }

  private toInterface(model: any): UserMemory {
    return {
      id: model.get('id') as string,
      userId: model.get('user_id') as string,
      key: model.get('key') as string,
      value: model.get('value') as string,
      createdAt: model.get('created_at') as Date,
      updatedAt: model.get('updated_at') as Date,
    };
  }

  async set(userId: string, key: string, value: string): Promise<UserMemory> {
    const [memory, created] = await UserMemoryModel.findOrCreate({
      where: { user_id: userId, key: key },
      defaults: { user_id: userId, key: key, value: value },
    });

    if (!created) {
      await memory.update({ value: value });
    }

    return this.toInterface(memory as any);
  }

  async get(userId: string, key: string): Promise<UserMemory | undefined> {
    const memory = await UserMemoryModel.findOne({
      where: { user_id: userId, key: key },
    });
    return memory ? this.toInterface(memory as any) : undefined;
  }

  async getAll(userId: string): Promise<UserMemory[]> {
    const memories = await UserMemoryModel.findAll({
      where: { user_id: userId },
      order: [['updated_at', 'DESC']],
    });
    return memories.map(m => this.toInterface(m as any));
  }

  async delete(userId: string, key: string): Promise<boolean> {
    const deletedCount = await UserMemoryModel.destroy({
      where: { user_id: userId, key: key },
    });
    return deletedCount > 0;
  }
}

export const userMemoryService = UserMemoryService.getInstance();
