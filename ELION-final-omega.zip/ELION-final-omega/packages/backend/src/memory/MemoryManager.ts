// packages/backend/src/memory/MemoryManager.ts

import { vectorStore } from './VectorStore';
import { MemoryEntry } from './db';

export class MemoryManager {
  private static instance: MemoryManager;

  public static getInstance(): MemoryManager {
    if (!MemoryManager.instance) {
      MemoryManager.instance = new MemoryManager();
    }
    return MemoryManager.instance;
  }

  /**
   * Saves an interaction (message) to the database and vector store.
   */
  async saveInteraction(
    projectId: string,
    role: 'user' | 'assistant' | 'system',
    content: string,
    sessionId: string
  ): Promise<void> {
    // 1. Save to the relational database (already handled by ChatService, but included here for completeness)
    // NOTE: This logic is now primarily handled by ChatService.sendMessage, but a full MemoryManager 
    // would orchestrate this. For now, we only use it for RAG context retrieval.
    
    // 2. Save to the vector store
    // Only save user messages to vector store for RAG context
    if (role === 'user') {
      await vectorStore.save(content, projectId, { role, sessionId, entry_type: 'chat_log' });
    }
  }

  /**
   * Retrieves relevant context from the vector store for RAG.
   */
  async retrieveContext(projectId: string, query: string): Promise<string> {
    const chunks = await vectorStore.retrieve(query, projectId);
    
    if (chunks.length === 0) {
      return "";
    }

    const context = chunks.map(chunk => `[Source: ${chunk.metadata.source || 'Memory'}] ${chunk.content}`).join('\n---\n');
    
    return context;
  }
}

export const memoryManager = MemoryManager.getInstance();
