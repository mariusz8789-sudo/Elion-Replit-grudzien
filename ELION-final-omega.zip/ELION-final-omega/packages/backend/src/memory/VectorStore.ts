// packages/backend/src/memory/VectorStore.ts

import { MemoryEntry } from './db';
import { embeddingService } from '../services/EmbeddingService';
import { literal, Op } from 'sequelize';

// Minimal Tool Interface (to be expanded later)
export interface MemoryChunk {
  id: string;
  content: string;
  score: number;
  metadata: any;
}

export class VectorStore {
  private static instance: VectorStore;
  private readonly embeddingDimension = 1536; // Dimension for text-embedding-3-small

  public static getInstance(): VectorStore {
    if (!VectorStore.instance) {
      VectorStore.instance = new VectorStore();
    }
    return VectorStore.instance;
  }

  /**
   * Retrieves relevant context from the vector store using vector similarity search.
   * @param query The user's query.
   * @param projectId The project ID for scoping.
   * @returns A list of relevant memory chunks.
   */
  async retrieve(query: string, projectId: string): Promise<MemoryChunk[]> {
    const queryEmbedding = await embeddingService.generateEmbedding(query);

    if (!queryEmbedding) {
      console.warn('[VectorStore] Embedding generation failed or disabled. Falling back to keyword search.');
      // Fallback to simple keyword search if embedding is not available
      const entries = await MemoryEntry.findAll({
        where: {
          project_id: projectId,
          content: { [Op.iLike]: `%${query}%` },
          embedding: { [Op.ne]: null } // Only search entries that were intended to be embedded
        },
        limit: 3,
      });
      return entries.map(entry => ({
        id: entry.get('id') as string,
        content: entry.get('content') as string,
        score: 0.5, // Mock score for keyword search
        metadata: entry.get('metadata') as any,
      }));
    }

    // Vector Search using pgvector's cosine distance operator (<=>)
    const entries = await MemoryEntry.findAll({
      where: {
        project_id: projectId,
        embedding: { [Op.ne]: null } // Only search entries that have an embedding
      },
      attributes: {
        include: [
          [
            literal(`embedding <=> '[${queryEmbedding.join(',')}]'`),
            'score',
          ],
        ],
      },
      order: literal('score ASC'), // Lower score is better (closer to 0)
      limit: 5,
    });

    return entries.map(entry => ({
      id: entry.get('id') as string,
      content: entry.get('content') as string,
      score: 1 - (entry.get('score') as number), // Convert distance (0=best) to similarity (1=best)
      metadata: entry.get('metadata') as any,
    }));
  }

  /**
   * Saves a memory chunk to the database, generating an embedding first.
   */
  async save(content: string, projectId: string, metadata: any): Promise<void> {
    const embedding = await embeddingService.generateEmbedding(content);

    // Save to the database (MemoryEntry model)
    await MemoryEntry.create({
      project_id: projectId,
      entry_type: 'rag_context', // Mark as RAG context
      role: 'system', // Context is system-generated
      content: content,
      embedding: embedding,
      metadata: metadata,
    });
  }
}

export const vectorStore = VectorStore.getInstance();
