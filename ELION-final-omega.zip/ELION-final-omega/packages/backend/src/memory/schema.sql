-- packages/backend/src/memory/schema.sql
-- This file is for reference. The actual schema is managed by Sequelize in db.ts.

-- Table for conversation threads/sessions
CREATE TABLE IF NOT EXISTS project_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID,
    title VARCHAR(255) NOT NULL,
    is_favorite BOOLEAN DEFAULT FALSE,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Table for memory entries (messages, code snippets, RAG context)
CREATE TABLE IF NOT EXISTS memory_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID REFERENCES project_sessions(id) ON DELETE CASCADE,
    project_id UUID NOT NULL,
    entry_type VARCHAR(50) NOT NULL, -- 'chat_log', 'code_snippet', 'rag_context'
    role VARCHAR(50), -- 'user', 'assistant', 'system'
    content TEXT NOT NULL,
    embedding REAL[], -- Placeholder for vector (requires pgvector extension)
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Index for faster retrieval
CREATE INDEX IF NOT EXISTS idx_memory_entries_session_id ON memory_entries(session_id);
CREATE INDEX IF NOT EXISTS idx_memory_entries_project_id ON memory_entries(project_id);
