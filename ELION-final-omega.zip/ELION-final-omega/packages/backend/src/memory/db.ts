// packages/backend/src/memory/db.ts

import { Sequelize, DataTypes } from 'sequelize';
import dotenv from 'dotenv';
import { Pool } from 'pg';

dotenv.config();

// --- Sequelize ORM Setup ---
// Use DATABASE_URL if available (Replit), otherwise fall back to individual env vars
const sequelize = process.env.DATABASE_URL
  ? new Sequelize(process.env.DATABASE_URL, {
      dialect: 'postgres',
      logging: false,
      dialectOptions: {
        ssl: process.env.DATABASE_URL.includes('sslmode=require') ? {
          require: true,
          rejectUnauthorized: false
        } : false
      }
    })
  : new Sequelize(
      process.env.DB_NAME || 'elion_omega_db',
      process.env.DB_USER || 'elion_user',
      process.env.DB_PASSWORD || 'elion_password',
      {
        host: process.env.DB_HOST || 'localhost',
        port: parseInt(process.env.DB_PORT || '5432'),
        dialect: 'postgres',
        logging: false,
      }
    );

// --- Raw PG Pool for Migrations/Schema Management ---
export const pool = process.env.DATABASE_URL
  ? new Pool({ connectionString: process.env.DATABASE_URL })
  : new Pool({
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT || '5432'),
      user: process.env.DB_USER || 'elion_user',
      password: process.env.DB_PASSWORD || 'elion_password',
      database: process.env.DB_NAME || 'elion_omega_db',
    });

// --- Define Models ---

// Function to enable pgvector extension
async function enablePgVector() {
  try {
    await sequelize.query('CREATE EXTENSION IF NOT EXISTS vector;');
    console.log('pgvector extension enabled.');
  } catch (error) {
    console.error('Could not enable pgvector extension. Ensure it is installed on your PostgreSQL server.', error);
  }
}

// 1. ProjectSession (ConversationThread)
export const ProjectSession = sequelize.define('ProjectSession', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  project_id: {
    type: DataTypes.UUID,
    allowNull: true,
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  is_favorite: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
  metadata: {
    type: DataTypes.JSONB,
    defaultValue: {},
  },
}, {
  tableName: 'project_sessions',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
});

// 3. UserMemory
export const UserMemory = sequelize.define('UserMemory', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  user_id: {
    type: DataTypes.UUID,
    allowNull: false,
  },
  key: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  value: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  metadata: {
    type: DataTypes.JSONB,
    defaultValue: {},
  },
}, {
  tableName: 'user_memory',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
  indexes: [
    {
      unique: true,
      fields: ['user_id', 'key'],
    },
  ],
});

// 2. MemoryEntry (Message)

// Call enablePgVector before defining models that use vector type
enablePgVector();
export const MemoryEntry = sequelize.define('MemoryEntry', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  session_id: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: ProjectSession,
      key: 'id',
    },
    onDelete: 'CASCADE',
  },
  project_id: {
    type: DataTypes.UUID,
    allowNull: false,
  },
  entry_type: {
    type: DataTypes.STRING, // e.g., 'chat_log', 'code_snippet', 'rag_context'
    allowNull: false,
  },
  role: {
    type: DataTypes.STRING, // 'user', 'assistant', 'system'
    allowNull: true,
  },
  content: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  embedding: {
    type: DataTypes.ARRAY(DataTypes.FLOAT), // This is the standard Sequelize type for array of floats
    allowNull: true,
  },
  metadata: {
    type: DataTypes.JSONB,
    defaultValue: {},
  },
}, {
  tableName: 'memory_entries',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
});

// --- Associations ---
ProjectSession.hasMany(MemoryEntry, { foreignKey: 'session_id', as: 'messages' });
MemoryEntry.belongsTo(ProjectSession, { foreignKey: 'session_id', as: 'session' });

// --- Database Connection and Sync ---
export async function connectDB() {
  try {
    await sequelize.authenticate();
    console.log('Database connection has been established successfully.');
  } catch (error) {
    console.error('Unable to connect to the database:', error);
    throw error;
  }
}

export async function syncDB() {
  // Use force: true only for development/testing to drop tables
  await sequelize.sync({ alter: true }); 
  console.log('Database synchronized (tables created/updated).');
}

// --- Minimal Migration/Schema Logic (for db:migrate script) ---
async function runMigrations() {
  console.log('Running migrations...');
  try {
    // This is a simplified migration. In a real app, we'd use a dedicated tool.
    await sequelize.sync({ alter: true });
    console.log('Migrations complete.');
  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  }
}

async function runSeed() {
  console.log('Running seed...');
  // Minimal seed logic: create a default project and a chat thread
  const defaultProjectId = '00000000-0000-0000-0000-000000000000';
  const defaultProject = await ProjectSession.findOne({ where: { project_id: defaultProjectId } });

  if (!defaultProject) {
    const session = await ProjectSession.create({
      project_id: defaultProjectId,
      title: 'Welcome to ELION OMEGA',
      is_favorite: true,
    });
    console.log(`Seeded default session: ${session.get('id')}`);
  } else {
    console.log('Default session already exists.');
  }
  console.log('Seed complete.');
}

// Command line interface for scripts
if (require.main === module) {
  const command = process.argv[2];
  if (command === 'migrate') {
    runMigrations().then(() => process.exit(0));
  } else if (command === 'seed') {
    runSeed().then(() => process.exit(0));
  } else {
    console.log('Usage: ts-node src/memory/db.ts [migrate|seed]');
    process.exit(1);
  }
}

export default sequelize;
