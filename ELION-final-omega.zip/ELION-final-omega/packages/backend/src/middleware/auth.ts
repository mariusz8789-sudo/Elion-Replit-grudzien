// packages/backend/src/middleware/auth.ts

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';

dotenv.config();

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';

// Extend the Request interface to include user property
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        firstName: string;
        role: string;
      };
    }
  }
}

export const authenticate = (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    // For development simplicity, allow unauthenticated access if no token is provided
    // In production, this should return 401
    // return res.status(401).json({ error: 'Access denied. No token provided.' });
    req.user = { id: '00000000-0000-0000-0000-000000000001', firstName: 'Dev', role: 'architect' };
    return next();
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { sub: string, firstName: string, role: string };
    
    // Attach user data to the request object
    req.user = {
      id: decoded.sub,
      firstName: decoded.firstName,
      role: decoded.role,
    };

    next();
  } catch (ex) {
    // If token is invalid or expired
    res.status(400).json({ error: 'Invalid token.' });
  }
};
