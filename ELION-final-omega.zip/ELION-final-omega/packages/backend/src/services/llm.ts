// packages/backend/src/services/llm.ts

import OpenAI from 'openai';
import dotenv from 'dotenv';
import { Stream } from 'openai/streaming';
import { ChatCompletionMessageToolCall } from 'openai/resources/chat/completions';

dotenv.config();

const apiKey = process.env.OPENAI_API_KEY;
// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const model = 'gpt-5';

if (!apiKey) {
  console.warn('[LLM] WARNING: OPENAI_API_KEY is missing. Using minimal stub implementation.');
}

const openai = apiKey ? new OpenAI({ apiKey }) : null;

export interface LLMMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string | null;
  tool_calls?: ChatCompletionMessageToolCall[];
  tool_call_id?: string;
}

export interface LLMResponse {
  content: string | null;
  tool_calls?: ChatCompletionMessageToolCall[];
}

/**
 * Generates a response from the LLM, supporting tool calls.
 * This is the non-streaming version used by the Agent Core.
 */
export const generateLLMResponse = async (
  messages: LLMMessage[],
  temperature: number = 0.2,
  tools?: OpenAI.Chat.Completions.ChatCompletionTool[]
): Promise<LLMResponse> => {
  if (!openai) {
    // Fallback to minimal stub if API key is missing
    const lastUserMessage = messages.slice().reverse().find(m => m.role === 'user')?.content || "Hello";
    return { content: `Cześć! Jestem ELION OMEGA. Mój klucz API jest nieustawiony, więc używam minimalnego stuba. Ustaw OPENAI_API_KEY w .env, aby użyć GPT-4o-mini. Ostatnia wiadomość: ${lastUserMessage}` };
  }

  try {
    // gpt-5 doesn't support temperature parameter
    const response = await openai.chat.completions.create({
      model: model,
      messages: messages as OpenAI.Chat.Completions.ChatCompletionMessageParam[],
      tools,
      tool_choice: tools ? "auto" : undefined,
    });

    const choice = response.choices[0];
    return {
      content: choice.message.content,
      tool_calls: choice.message.tool_calls,
    };
  } catch (error: any) {
    console.error('[LLM] OpenAI API Error:', error);
    return { content: `Wystąpił błąd podczas komunikacji z modelem AI: ${error.message}. Sprawdź swój klucz API i status usługi.` };
  }
};

/**
 * Generates a streaming response from the LLM (SSE).
 * This is used by the Chat Routes for real-time output.
 */
export const streamLLMResponse = async (
  messages: LLMMessage[],
  temperature: number = 0.2
): Promise<Stream<OpenAI.Chat.Completions.ChatCompletionChunk>> => {
  if (!openai) {
    throw new Error("OpenAI API key is not set. Cannot stream response.");
  }

  try {
    // gpt-5 doesn't support temperature parameter
    const stream = await openai.chat.completions.create({
      model: model,
      messages: messages as OpenAI.Chat.Completions.ChatCompletionMessageParam[],
      stream: true,
    });
    return stream;
  } catch (error: any) {
    console.error('[LLM] OpenAI Streaming API Error:', error);
    throw new Error(`Wystąpił błąd podczas streamingu: ${error.message}`);
  }
};
