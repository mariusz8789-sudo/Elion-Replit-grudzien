// packages/backend/src/services/EmbeddingService.ts

import OpenAI from 'openai';
import dotenv from 'dotenv';

dotenv.config();

const apiKey = process.env.OPENAI_API_KEY;
const embeddingModel = process.env.OPENAI_EMBEDDING_MODEL || 'text-embedding-3-small';

if (!apiKey) {
  console.warn('[EmbeddingService] WARNING: OPENAI_API_KEY is missing. Embedding generation will be disabled.');
}

const openai = apiKey ? new OpenAI({ apiKey }) : null;

export class EmbeddingService {
  private static instance: EmbeddingService;

  public static getInstance(): EmbeddingService {
    if (!EmbeddingService.instance) {
      EmbeddingService.instance = new EmbeddingService();
    }
    return EmbeddingService.instance;
  }

  /**
   * Generates an embedding vector for a given text.
   * @param text The text to embed.
   * @returns A promise that resolves to the embedding vector (array of numbers) or null if disabled.
   */
  async generateEmbedding(text: string): Promise<number[] | null> {
    if (!openai) {
      return null;
    }

    try {
      const response = await openai.embeddings.create({
        model: embeddingModel,
        input: text,
      });

      return response.data[0].embedding;
    } catch (error) {
      console.error('[EmbeddingService] Error generating embedding:', error);
      return null;
    }
  }
}

export const embeddingService = EmbeddingService.getInstance();
