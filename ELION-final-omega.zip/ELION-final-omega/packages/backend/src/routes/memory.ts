// packages/backend/src/routes/memory.ts

import { Router } from 'express';

const router = Router();

router.get('/', (req, res) => {
  res.json({ message: 'memory route is active' });
});

export default router;
