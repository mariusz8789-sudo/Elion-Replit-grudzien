// packages/backend/src/routes/status.ts

import { Router } from 'express';

const router = Router();

router.get('/', (req, res) => {
  res.json({ message: 'status route is active' });
});

export default router;
