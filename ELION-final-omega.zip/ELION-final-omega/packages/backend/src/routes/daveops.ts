// packages/backend/src/routes/daveops.ts

import { Router, Request, Response } from 'express';
import { daveOpsOrchestrator } from '../daveops/Orchestrator';
import { DeploymentTarget } from '../daveops/types';

const router = Router();

// POST /api/daveops/deploy
router.post('/deploy', async (req: Request, res: Response) => {
  const { projectId, target } = req.body; // target: 'docker' | 'vercel'
  const userId = req.user?.id || 'default-user';
  
  if (!projectId || !target) {
    return res.status(400).json({ error: 'Missing projectId or target' });
  }

  if (!['docker', 'vercel'].includes(target)) {
    return res.status(400).json({ error: 'Invalid deployment target' });
  }

  try {
    const status = await daveOpsOrchestrator.startDeployment(projectId, target as DeploymentTarget);
    res.json({
      message: `Deployment started for project ${projectId} to ${target}.`,
      taskId: status.taskId,
      status: status.status,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to start deployment' });
  }
});

// GET /api/daveops/status/:taskId
router.get('/status/:taskId', (req: Request, res: Response) => {
  const { taskId } = req.params;
  
  const status = daveOpsOrchestrator.getTaskStatus(taskId);
  
  if (!status) {
    return res.status(404).json({ error: 'Task not found' });
  }

  res.json(status);
});

export default router;
