// packages/backend/src/routes/autodev.ts

import { Router, Request, Response } from 'express';
import { autoDevService } from '../autodev/AutoDevService';

const router = Router();

// POST /api/autodev/start
router.post('/start', async (req: Request, res: Response) => {
  const { projectId, goal } = req.body;
  const userId = req.user?.id || 'default-user';
  
  if (!projectId || !goal) {
    return res.status(400).json({ error: 'Missing projectId or goal' });
  }

  try {
    const task = await autoDevService.startTask(projectId, goal);
    res.json({
      message: `AutoDev task started for project ${projectId}.`,
      taskId: task.taskId,
      status: task.status,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to start AutoDev task' });
  }
});

// GET /api/autodev/status/:taskId
router.get('/status/:taskId', (req: Request, res: Response) => {
  const { taskId } = req.params;
  
  const status = autoDevService.getTaskStatus(taskId);
  
  if (!status) {
    return res.status(404).json({ error: 'Task not found' });
  }

  res.json(status);
});

export default router;
