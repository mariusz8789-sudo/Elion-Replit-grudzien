// packages/backend/src/routes/chat.ts

import { Router, Request, Response } from 'express';
import { chatService } from '../chat/ChatService';

import { Message } from '../models/chat';

const router = Router();

// GET /api/chat/threads
router.get('/threads', async (req: Request, res: Response) => {
  try {
    const threads = await chatService.getThreads();
    res.json(threads);
  } catch (error: any) {
    console.error('Error loading threads:', error);
    res.status(500).json({ error: error.message || 'Failed to load threads' });
  }
});

// POST /api/chat/threads
router.post('/threads', async (req: Request, res: Response) => {
  const { title } = req.body;
  const thread = await chatService.createThread(title, req.user?.id);
  res.json(thread);
});

// PATCH /api/chat/threads/:id
router.patch('/threads/:id', async (req: Request, res: Response) => {
  const { id } = req.params;
  const updates = req.body;

  const updated = await chatService.updateThread(id, updates);
  if (!updated) {
    return res.status(404).json({ error: 'Thread not found' });
  }

  res.json(updated);
});

// DELETE /api/chat/threads/:id
router.delete('/threads/:id', async (req: Request, res: Response) => {
  const { id } = req.params;
  const deleted = await chatService.deleteThread(id);

  if (!deleted) {
    return res.status(404).json({ error: 'Thread not found' });
  }

  res.json({ success: true });
});

// GET /api/chat/threads/:id/messages
router.get('/threads/:id/messages', async (req: Request, res: Response) => {
  const { id } = req.params;
  const messages = await chatService.getMessages(id);
  res.json(messages);
});

// POST /api/chat/threads/:id/messages (Send Message)
router.post('/threads/:id/messages', async (req: Request, res: Response) => {
  const { id } = req.params;
  const { content } = req.body;

  if (!content) {
    return res.status(400).json({ error: 'Message content is required' });
  }

  try {
    const { userMessage, assistantMessage } = await chatService.sendMessage(id, content, req.user?.id);

    res.json({
      userMessage,
      assistantMessage
    });
  } catch (error: any) {
    console.error('Chat error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

export default router;
