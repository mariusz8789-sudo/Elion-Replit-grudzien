// packages/backend/src/routes/builder.ts

import { Router, Request, Response } from 'express';
import { builderService } from '../builder/BuilderService';

const router = Router();

// POST /api/builder/start
router.post('/start', async (req: Request, res: Response) => {
  const { projectId, target } = req.body;
  
  if (!projectId || !target) {
    return res.status(400).json({ error: 'Missing projectId or target' });
  }

  try {
    const task = await builderService.startBuild(projectId, target);
    res.json({
      message: `Build task started for project ${projectId}.`,
      taskId: task.taskId,
      status: task.status,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to start build task' });
  }
});

// GET /api/builder/status/:taskId
router.get('/status/:taskId', (req: Request, res: Response) => {
  const { taskId } = req.params;
  
  const status = builderService.getTaskStatus(taskId);
  
  if (!status) {
    return res.status(404).json({ error: 'Task not found' });
  }

  res.json(status);
});

export default router;
