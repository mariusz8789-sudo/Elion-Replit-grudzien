// packages/backend/src/daveops/types.ts

export type DeploymentTarget = 'docker' | 'vercel';

export interface DeploymentStatus {
  taskId: string;
  status: 'PENDING' | 'RUNNING' | 'SUCCESS' | 'FAILED';
  logs: string[];
  url?: string;
}
