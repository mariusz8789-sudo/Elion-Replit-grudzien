// packages/backend/src/daveops/Orchestrator.ts

import { dockerService } from './DockerService';
import { DeploymentStatus, DeploymentTarget } from './types';
import { vercelService } from './VercelService';



export class DaveOpsOrchestrator {
  private static instance: DaveOpsOrchestrator;

  public static getInstance(): DaveOpsOrchestrator {
    if (!DaveOpsOrchestrator.instance) {
      DaveOpsOrchestrator.instance = new DaveOpsOrchestrator();
    }
    return DaveOpsOrchestrator.instance;
  }

  /**
   * Starts a deployment process based on the target.
   */
  async startDeployment(projectId: string, target: DeploymentTarget): Promise<DeploymentStatus> {
    console.log(`[DaveOps] Starting deployment for project ${projectId} to ${target}...`);
    
    switch (target) {
      case 'docker':
        // In a real scenario, this would chain buildImage and deployContainer
        return dockerService.deployContainer(projectId, `${projectId}:latest`);
      case 'vercel':
        return vercelService.deploy(projectId);
      default:
        throw new Error(`Unsupported deployment target: ${target}`);
    }
  }

  /**
   * Retrieves the status of a running deployment task.
   */
  getTaskStatus(taskId: string): DeploymentStatus | undefined {
    // Check both services as we don't know the target from the ID alone in this minimal stub
    let status = dockerService.getDeploymentStatus(taskId);
    if (status) return status;
    
    status = vercelService.getDeploymentStatus(taskId);
    return status;
  }
}

export const daveOpsOrchestrator = DaveOpsOrchestrator.getInstance();
