// packages/backend/src/daveops/VercelService.ts

import { DeploymentStatus } from './types';

// NOTE: In a real environment, this would use a library like 'axios' to call the Vercel API.
// Here, we maintain the async simulation but with a more robust structure.

export class VercelService {
  private static instance: VercelService;
  private deployments: Map<string, DeploymentStatus> = new Map();

  public static getInstance(): VercelService {
    if (!VercelService.instance) {
      VercelService.instance = new VercelService();
    }
    return VercelService.instance;
  }

  /**
   * Simulates deployment to Vercel.
   */
  async deploy(projectId: string): Promise<DeploymentStatus> {
    const taskId = `vercel-deploy-${Date.now()}`;
    const url = `https://${projectId}.vercel.app`;
    const status: DeploymentStatus = {
      taskId,
      status: 'RUNNING',
      logs: [`[${new Date().toISOString()}] Starting Vercel deployment for project ${projectId}... (Real Vercel API call simulated)`],
      url,
    };
    this.deployments.set(taskId, status);

    // Simulate async process
    setTimeout(() => {
      const finalStatus = this.deployments.get(taskId);
      if (finalStatus) {
        finalStatus.status = 'SUCCESS';
        finalStatus.logs.push(`[${new Date().toISOString()}] Vercel deployment successful. Access at ${url}`);
      }
    }, 10000);

    return status;
  }

  /**
   * Retrieves the status and logs for a given task ID.
   */
  getDeploymentStatus(taskId: string): DeploymentStatus | undefined {
    // Ensure logs are up-to-date for RUNNING tasks
    const status = this.deployments.get(taskId);
    if (status && status.status === 'RUNNING') {
      status.logs.push(`[${new Date().toISOString()}] Deployment still in progress...`);
    }
    return status;
  }
}

export const vercelService = VercelService.getInstance();
