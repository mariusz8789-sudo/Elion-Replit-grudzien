// packages/backend/src/agent/core.ts

import { generateLLMResponse, LLMMessage } from '../services/llm';
import { memoryManager } from '../memory/MemoryManager';
import { daveOpsOrchestrator } from '../daveops/Orchestrator';
import { autoDevService } from '../autodev/AutoDevService';
import { userMemoryService } from '../memory/UserMemoryService';
import OpenAI from 'openai';
import { ChatCompletionTool } from 'openai/resources/chat/completions';

// --- Tool Definitions ---

export interface AgentTool {
  name: string;
  description: string;
  parameters: any;
  execute: (args: any, projectId: string, userId: string) => Promise<string>;
}

const toolDefinitions: AgentTool[] = [
  {
    name: "get_system_status",
    description: "Retrieves the current operational status of the ELION OMEGA system components. Use this when the user asks about the system's health or status.",
    parameters: {
      type: "object",
      properties: {},
      required: [],
    },
    execute: async () => {
      return JSON.stringify({ status: "Operational", components: { chat: "OK", db: "OK", llm: "OK (Ready for use)" } });
    }
  },
  {
    name: "retrieve_memory",
    description: "Searches the project memory (RAG) for relevant context based on a query. Use this to answer questions about the project's history, architecture, or any previously saved information.",
    parameters: {
      type: "object",
      properties: {
        query: {
          type: "string",
          description: "The search query to find relevant context in the project memory.",
        },
      },
      required: ["query"],
    },
    execute: async (args, projectId) => {
      const context = await memoryManager.retrieveContext(projectId, args.query);
      return context.length > 0 ? `Found context:\n${context}` : "No relevant context found in project memory.";
    }
  },
  {
    name: "start_autodev_task",
    description: "Starts a new AutoDev task to implement a feature, fix a bug, or refactor code. Use this when the user asks to start development work.",
    parameters: {
      type: "object",
      properties: {
        goal: {
          type: "string",
          description: "A clear, concise description of the development goal (e.g., 'Implement user authentication with JWT').",
        },
        projectId: {
          type: "string",
          description: "The ID of the project to work on.",
        },
      },
      required: ["goal", "projectId"],
    },
    execute: async (args) => {
      const task = await autoDevService.startTask(args.projectId, args.goal);
      return `AutoDev task started successfully. Task ID: ${task.taskId}. Current Status: ${task.status}.`;
    }
  },
  {
    name: "start_daveops_deployment",
    description: "Starts a deployment process for a project to a specified target (docker or vercel). Use this when the user asks to deploy the project.",
    parameters: {
      type: "object",
      properties: {
        projectId: {
          type: "string",
          description: "The ID of the project to deploy.",
        },
        target: {
          type: "string",
          enum: ["docker", "vercel"],
          description: "The deployment target.",
        },
      },
      required: ["projectId", "target"],
    },
    execute: async (args) => {
      const status = await daveOpsOrchestrator.startDeployment(args.projectId, args.target);
      return `Deployment started. Task ID: ${status.taskId}. Current Status: ${status.status}.`;
    }
  },
  {
    name: "get_user_memory",
    description: "Retrieves a specific piece of personal memory (e.g., user preferences, API keys, personal notes) for the current user.",
    parameters: {
      type: "object",
      properties: {
        key: {
          type: "string",
          description: "The key of the memory to retrieve (e.g., 'preferred_language', 'vercel_api_key').",
        },
      },
      required: ["key"],
    },
    execute: async (args, _, userId) => {
      const memory = await userMemoryService.get(userId, args.key);
      return memory ? `User Memory for key '${args.key}': ${memory.value}` : `No user memory found for key '${args.key}'.`;
    }
  },
];

// --- Agent Core ---

export class ElionAgent {
  private tools: AgentTool[] = toolDefinitions;
  private toolFunctions: ChatCompletionTool[] = this.tools.map(tool => ({
    type: "function",
    function: {
      name: tool.name,
      description: tool.description,
      parameters: tool.parameters,
    }
  }));

  /**
   * Main method for the agent to process a user query.
   * @param query The user's message.
   * @param projectId The current project ID.
   * @param userId The current user ID.
   * @returns The agent's final response.
   */
  async run(query: string, projectId: string, userId: string): Promise<string> {
    // 1. RAG Context Retrieval
    const ragContext = await memoryManager.retrieveContext(projectId, query);

    // 2. System Prompt Construction
    const systemPrompt = this.buildSystemPrompt(ragContext);

    // 3. Initial LLM Call with Tools
    let messages: LLMMessage[] = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: query }
    ];

    let response = await generateLLMResponse(messages, 0.2, this.toolFunctions);

    // 4. Tool Use Loop (up to 3 iterations for multi-step reasoning)
    for (let i = 0; i < 3; i++) {
      if (response.tool_calls && response.tool_calls.length > 0) {
        const toolCall = response.tool_calls[0];
        const tool = this.tools.find(t => t.name === (toolCall as any).function.name);

        if (tool) {
          console.log(`[Agent] Executing tool: ${tool.name}`);
          
          // Execute the tool
          let toolOutput: string;
          try {
            const args = JSON.parse((toolCall as any).function.arguments);
            toolOutput = await tool.execute(args, projectId, userId);
          } catch (e: any) {
            toolOutput = `Tool execution failed: ${e.message}`;
          }

          // Add tool call and output to messages
          messages.push({
            role: 'assistant',
            content: null,
            tool_calls: [toolCall],
          });
          messages.push({
            role: 'tool',
            content: toolOutput,
            tool_call_id: toolCall.id,
          });

          // Call LLM again with tool output
          response = await generateLLMResponse(messages, 0.2, this.toolFunctions);
        } else {
          // Tool not found, break loop
          break;
        }
      } else {
        // No tool call, final answer received
        return response.content || "Przepraszam, nie otrzymałem odpowiedzi od modelu AI.";
      }
    }

    // Fallback: return the last response content
    return response.content || "Przepraszam, agent nie był w stanie sfinalizować odpowiedzi po wykonaniu narzędzi.";
  }

  private buildSystemPrompt(ragContext: string): string {
    let prompt = "You are ELION OMEGA, an advanced AI system architect and repair specialist. Your goal is to be helpful, concise, and use the provided tools and context when relevant.\n";
    
    if (ragContext) {
      prompt += `\n--- CONTEXT FROM PROJECT MEMORY (RAG) ---\n${ragContext}\n---\n`;
    }

    prompt += "\nIf a tool is relevant, you MUST use it. If you need to answer a question, you MUST use the 'retrieve_memory' tool first to check for context. If you use a tool, you MUST follow up with a final answer based on the tool's output.";
    return prompt;
  }
}

export const elionAgent = new ElionAgent();
