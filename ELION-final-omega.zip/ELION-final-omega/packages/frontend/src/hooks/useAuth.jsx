// packages/frontend/src/hooks/useAuth.jsx
// Re-export from the context for convenience
export { useAuth } from '../context/AuthContext.jsx';
