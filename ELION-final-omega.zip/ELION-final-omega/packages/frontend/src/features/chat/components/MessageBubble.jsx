// packages/frontend/src/features/chat/components/MessageBubble.jsx

import React from 'react';
import { Copy, Bookmark, Download, User, Bot } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

// Note: The original file was .tsx but the import in ChatHistoryPage was .jsx.
// We will use .jsx for simplicity and convert the interface to PropTypes/inline types.

// Minimal type definition for clarity
// interface Message {
//   id: string;
//   role: 'user' | 'assistant' | 'system';
//   content: string;
//   createdAt: number; // Using number as per backend model
// }

const ActionButton = ({ icon: Icon, label, onClick }) => (
  <button 
    onClick={onClick}
    className="flex items-center gap-1 text-[10px] text-gray-500 hover:text-[var(--color-accent)] transition-colors px-2 py-1 rounded hover:bg-[var(--color-bg-secondary)]"
  >
    <Icon size={12} /> {label}
  </button>
);

export default function MessageBubble({ message }) {
  const isUser = message.role === 'user';
  const isSystem = message.role === 'system';

  const handleCopy = () => navigator.clipboard.writeText(message.content);
  const handleExport = () => {
    const blob = new Blob([message.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `elion_export_${message.id}.txt`;
    a.click();
  };

  if (isSystem) return null; // Optionally hide system prompt

  return (
    <div className={`flex gap-4 ${isUser ? 'flex-row-reverse' : 'flex-row'} mb-6`}>
      
      {/* Avatar */}
      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
        isUser ? 'bg-[var(--color-accent)]' : 'bg-purple-600'
      }`}>
        {isUser ? <User size={16} className="text-black" /> : <Bot size={16} className="text-white" />}
      </div>

      {/* Content Bubble */}
      <div className={`flex flex-col max-w-[80%] ${isUser ? 'items-end' : 'items-start'}`}>
        <div className={`px-5 py-3 rounded-2xl text-sm leading-relaxed shadow-sm whitespace-pre-wrap ${
          isUser 
            ? 'bg-[var(--color-bg-secondary)] border border-[var(--color-border)] text-[var(--color-text-primary)] rounded-tr-none' 
            : 'bg-[var(--color-bg-primary)] border border-[var(--color-border)] text-[var(--color-text-primary)] rounded-tl-none'
        }`}>
          <ReactMarkdown remarkPlugins={[remarkGfm]}>
            {message.content}
          </ReactMarkdown>
        </div>

        {/* Action Bar (Only for Agent) */}
        {!isUser && (
          <div className="flex gap-2 mt-2 ml-2">
            <ActionButton icon={Copy} label="Copy" onClick={handleCopy} />
            <ActionButton icon={Bookmark} label="Memorize" onClick={() => alert('Saved to Memory (Mock)')} />
            <ActionButton icon={Download} label="Export" onClick={handleExport} />
          </div>
        )}
        
        <span className="text-[10px] text-gray-500 mt-1 px-1">
          {new Date(message.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
        </span>
      </div>
    </div>
  );
}
