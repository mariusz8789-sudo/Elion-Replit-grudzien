// packages/frontend/src/pages/LessonsPage.jsx

import React from 'react';
import { BookOpen, CheckCircle, XCircle } from 'lucide-react';

export default function LessonsPage() {
  const lessons = [
    {
      id: 1,
      title: "Security Lesson: JWT Token Invalidation",
      summary: "Learned how to properly invalidate JWT tokens on the server-side using a blocklist/revocation list stored in Redis.",
      status: "Success",
    },
    {
      id: 2,
      title: "Deployment Lesson: Vercel Build Failure",
      summary: "Identified that Vercel build was failing due to missing environment variables. Fixed by adding them to the Vercel project settings.",
      status: "Failure",
    },
    {
      id: 3,
      title: "Code Quality: Refactoring ChatService",
      summary: "Refactored the ChatService to use the Sequelize ORM, resulting in cleaner, more maintainable data access logic.",
      status: "Success",
    },
  ];

  return (
    <div className="p-8 space-y-8">
      <header className="flex items-center space-x-4">
        <BookOpen className="w-10 h-10 text-indigo-500" />
        <h1 className="text-3xl font-bold text-[var(--color-text-primary)]">Lessons Learned</h1>
      </header>

      <p className="text-[var(--color-text-secondary)] max-w-3xl">
        This section tracks all significant events, successes, and failures encountered by ELION OMEGA during development and deployment, providing valuable knowledge for future tasks.
      </p>

      <div className="space-y-4">
        {lessons.map((lesson) => (
          <div key={lesson.id} className="p-6 bg-[var(--color-bg-secondary)] rounded-lg shadow-lg border border-[var(--color-border)] flex items-start space-x-4">
            {lesson.status === 'Success' ? (
              <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
            ) : (
              <XCircle className="w-6 h-6 text-red-500 flex-shrink-0 mt-1" />
            )}
            <div>
              <h2 className="text-xl font-semibold text-[var(--color-text-primary)] mb-1">{lesson.title}</h2>
              <p className="text-[var(--color-text-secondary)]">{lesson.summary}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
