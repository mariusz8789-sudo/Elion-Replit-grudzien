// packages/frontend/src/pages/AgiPage.jsx

import React from 'react';
import { Zap, Settings, Clock } from 'lucide-react';

export default function AgiPage() {
  return (
    <div className="p-8 space-y-8">
      <header className="flex items-center space-x-4">
        <Zap className="w-10 h-10 text-yellow-500" />
        <h1 className="text-3xl font-bold text-[var(--color-text-primary)]">AGI Orchestration</h1>
      </header>

      <p className="text-[var(--color-text-secondary)] max-w-3xl">
        This module is the control center for complex, multi-step AI operations. It orchestrates the **ElionAgent**, **AutoDev**, and **DaveOps** services to achieve high-level goals, such as "Implement a new feature" or "Fix all critical bugs."
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-6 bg-[var(--color-bg-secondary)] rounded-lg shadow-lg border border-[var(--color-border)]">
          <Settings className="w-6 h-6 text-[var(--color-accent)] mb-3" />
          <h2 className="text-xl font-semibold text-[var(--color-text-primary)] mb-2">Current Goal</h2>
          <p className="text-[var(--color-text-secondary)]">Implement full User Authentication using JWT and Postgres.</p>
          <button className="mt-4 text-sm text-[var(--color-accent)] hover:underline">
            View Pipeline
          </button>
        </div>

        <div className="p-6 bg-[var(--color-bg-secondary)] rounded-lg shadow-lg border border-[var(--color-border)]">
          <Clock className="w-6 h-6 text-blue-500 mb-3" />
          <h2 className="text-xl font-semibold text-[var(--color-text-primary)] mb-2">Last Activity</h2>
          <p className="text-[var(--color-text-secondary)]">DaveOps deployment to Vercel completed successfully.</p>
          <p className="text-xs text-[var(--color-text-tertiary)] mt-1">2 hours ago</p>
        </div>

        <div className="p-6 bg-[var(--color-bg-secondary)] rounded-lg shadow-lg border border-[var(--color-border)]">
          <Zap className="w-6 h-6 text-green-500 mb-3" />
          <h2 className="text-xl font-semibold text-[var(--color-text-primary)] mb-2">Status</h2>
          <p className="text-green-500 font-bold">Awaiting Next Instruction</p>
          <p className="text-xs text-[var(--color-text-tertiary)] mt-1">Ready to receive a new high-level task.</p>
        </div>
      </div>

      <section className="pt-4">
        <h2 className="text-2xl font-bold text-[var(--color-text-primary)] mb-4">Start New Orchestration</h2>
        <div className="bg-[var(--color-bg-secondary)] p-6 rounded-lg border border-[var(--color-border)]">
          <textarea
            className="w-full p-3 border border-[var(--color-border)] rounded-lg bg-[var(--color-bg-primary)] text-[var(--color-text-primary)] focus:outline-none focus:focus:border-[var(--color-accent)]"
            rows="4"
            placeholder="Enter a high-level goal for ELION OMEGA (e.g., 'Implement a dark mode toggle on the frontend')."
          ></textarea>
          <button className="mt-4 px-6 py-2 bg-[var(--color-accent)] text-white font-semibold rounded-lg hover:opacity-90 transition-opacity">
            Start AGI Task
          </button>
        </div>
      </section>
    </div>
  );
}
