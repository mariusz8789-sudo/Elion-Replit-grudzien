// packages/frontend/src/pages/ChatHistoryPage.jsx

import React, { useState, useEffect, useRef } from 'react';
import { chatApi } from '../lib/api';
import {
  MessageSquare,
  Plus,
  Search,
  Star,
  Trash2,
  Send,
  MoreVertical,
  FileText,
  Bot,
  User,
  Loader2,
} from 'lucide-react';
import MessageBubble from '../features/chat/components/MessageBubble'; // Assuming this component exists
import Terminal from '../components/Terminal'; // Assuming this component exists

export default function ChatHistoryPage() {
  const [threads, setThreads] = useState([]);
  const [activeThreadId, setActiveThreadId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isLoadingThreads, setIsLoadingThreads] = useState(true);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterFavorites, setFilterFavorites] = useState(false);

  const messagesEndRef = useRef(null);

  // Initial Load
  useEffect(() => {
    loadThreads();
  }, []);

  // Load messages when active thread changes
  useEffect(() => {
    if (activeThreadId) {
      loadMessages(activeThreadId);
    } else {
      setMessages([]);
    }
  }, [activeThreadId]);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isSending]);

  const loadThreads = async () => {
    try {
      const { data } = await chatApi.getThreads();
      setThreads(data);
    } catch (error) {
      console.error('Failed to load threads', error);
    } finally {
      setIsLoadingThreads(false);
    }
  };

  const loadMessages = async (threadId) => {
    setIsLoadingMessages(true);
    try {
      const { data } = await chatApi.getMessages(threadId);
      setMessages(data);
    } catch (error) {
      console.error('Failed to load messages', error);
    } finally {
      setIsLoadingMessages(false);
    }
  };

  const handleCreateThread = async () => {
    try {
      const { data } = await chatApi.createThread('New Conversation');
      setThreads((prev) => [data, ...prev]);
      setActiveThreadId(data.id);
    } catch (error) {
      console.error('Failed to create thread', error);
    }
  };

  const handleDeleteThread = async (e, id) => {
    e.stopPropagation();
    if (!window.confirm('Are you sure you want to delete this conversation?')) return;

    try {
      await chatApi.deleteThread(id);
      setThreads((prev) => prev.filter((t) => t.id !== id));
      if (activeThreadId === id) {
        setActiveThreadId(null);
        setMessages([]);
      }
    } catch (error) {
      console.error('Failed to delete thread', error);
    }
  };

  const handleToggleFavorite = async (e, thread) => {
    e.stopPropagation();
    try {
      const updated = { isFavorite: !thread.isFavorite };
      const { data } = await chatApi.updateThread(thread.id, updated);
      setThreads((prev) => prev.map((t) => (t.id === thread.id ? data : t)));
    } catch (error) {
      console.error('Failed to update thread', error);
    }
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!input.trim() || !activeThreadId || isSending) return;

    const content = input.trim();
    setInput('');
    setIsSending(true);

    // Optimistic User Message
    const tempId = Date.now().toString();
    const optimisticMsg = {
      id: tempId,
      role: 'user',
      content: content,
      createdAt: Date.now(),
    };
    setMessages((prev) => [...prev, optimisticMsg]);

    try {
      const { data } = await chatApi.sendMessage(activeThreadId, content);
      // Replace optimistic message and add assistant response
      setMessages((prev) => [
        ...prev.filter((m) => m.id !== tempId),
        data.userMessage,
        data.assistantMessage,
      ]);

      // Update thread list (timestamps, messageCount)
      loadThreads();
    } catch (error) {
      console.error('Failed to send message', error);
      setMessages((prev) => prev.filter((m) => m.id !== tempId)); // Revert optimistic
      alert('Failed to send message. Please check connection.');
    } finally {
      setIsSending(false);
    }
  };

  const filteredThreads = threads.filter((t) => {
    const matchesSearch = t.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterFavorites ? t.isFavorite : true;
    return matchesSearch && matchesFilter;
  });

  const activeThreadData = threads.find((t) => t.id === activeThreadId);

  return (
    <div className="flex h-full bg-[var(--color-bg-primary)] rounded-lg overflow-hidden border border-[var(--color-border)] shadow-xl">
      {/* LEFT SIDEBAR: Threads List */}
      <div className="w-80 border-r border-[var(--color-border)] flex flex-col bg-[var(--color-bg-secondary)]">
        <div className="p-4 border-b border-[var(--color-border)]">
          <button
            onClick={handleCreateThread}
            className="w-full flex items-center justify-center gap-2 bg-[var(--color-accent)] text-white py-2 px-4 rounded-lg font-bold hover:opacity-90 transition-opacity"
          >
            <Plus size={18} /> New Chat
          </button>
        </div>

        <div className="p-3 space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 text-gray-400" size={16} />
            <input
              type="text"
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-[var(--color-bg-primary)] border border-[var(--color-border)] rounded-lg text-sm focus:outline-none focus:border-[var(--color-accent)] text-[var(--color-text-primary)]"
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setFilterFavorites(!filterFavorites)}
              className={`text-xs px-3 py-1 rounded-full border transition-colors ${
                filterFavorites
                  ? 'bg-yellow-500/20 border-yellow-500/50 text-yellow-500'
                  : 'border-[var(--color-border)] text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-primary)]'
              }`}
            >
              Favorites Only
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {isLoadingThreads ? (
            <div className="flex justify-center p-8">
              <Loader2 className="animate-spin text-[var(--color-accent)]" />
            </div>
          ) : filteredThreads.length === 0 ? (
            <div className="text-center p-8 text-[var(--color-text-secondary)] text-sm">
              No threads found.
            </div>
          ) : (
            filteredThreads.map((thread) => (
              <div
                key={thread.id}
                onClick={() => setActiveThreadId(thread.id)}
                className={`p-4 border-b border-[var(--color-border)] cursor-pointer transition-colors hover:bg-[var(--color-bg-primary)] group ${
                  activeThreadId === thread.id
                    ? 'bg-[var(--color-bg-primary)] border-l-4 border-l-[var(--color-accent)]'
                    : ''
                }`}
              >
                <div className="flex justify-between items-start mb-1">
                  <h3
                    className={`text-sm font-semibold truncate ${
                      activeThreadId === thread.id
                        ? 'text-[var(--color-text-primary)]'
                        : 'text-[var(--color-text-secondary)]'
                    }`}
                  >
                    {thread.title}
                  </h3>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => handleToggleFavorite(e, thread)}
                      className={`p-1 rounded hover:bg-[var(--color-bg-secondary)] ${
                        thread.isFavorite ? 'text-yellow-500' : 'text-gray-400'
                      }`}
                    >
                      <Star size={12} fill={thread.isFavorite ? 'currentColor' : 'none'} />
                    </button>
                    <button
                      onClick={(e) => handleDeleteThread(e, thread.id)}
                      className="p-1 rounded hover:bg-red-900/20 text-gray-400 hover:text-red-500"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
                <div className="flex justify-between items-center text-xs text-[var(--color-text-secondary)] opacity-70">
                  <span>{new Date(thread.updatedAt).toLocaleDateString()}</span>
                  <span className="flex items-center gap-1">
                    <MessageSquare size={10} /> {thread.messageCount}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* RIGHT AREA: Messages */}
      <div className="flex-1 flex flex-col bg-[var(--color-bg-primary)]">
        {activeThreadId ? (
          <>
            {/* Header */}
            <div className="h-16 border-b border-[var(--color-border)] flex items-center justify-between px-6 bg-[var(--color-bg-secondary)]">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[var(--color-accent)]/10 rounded-lg text-[var(--color-accent)]">
                  <MessageSquare size={20} />
                </div>
                <h2 className="text-lg font-bold text-[var(--color-text-primary)]">
                  {activeThreadData?.title || 'Loading...'}
                </h2>
              </div>
              <button className="p-2 rounded-full hover:bg-[var(--color-bg-primary)] text-[var(--color-text-secondary)]">
                <MoreVertical size={20} />
              </button>
            </div>

            {/* Message Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {isLoadingMessages ? (
                <div className="flex justify-center p-8">
                  <Loader2 className="animate-spin text-[var(--color-accent)] size-8" />
                </div>
              ) : messages.length === 0 ? (
                <div className="text-center p-8 text-[var(--color-text-secondary)] text-sm">
                  Start a conversation with ELION OMEGA.
                </div>
              ) : (
                messages.map((message) => (
                  <MessageBubble
                    key={message.id}
                    message={message}
                    isUser={message.role === 'user'}
                  />
                ))
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="p-4 border-t border-[var(--color-border)] bg-[var(--color-bg-secondary)]">
              <form onSubmit={handleSendMessage} className="flex items-center gap-3">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder={isSending ? 'ELION is thinking...' : 'Message ELION OMEGA...'}
                  disabled={isSending}
                  className="flex-1 p-3 rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-primary)] text-[var(--color-text-primary)] focus:outline-none focus:border-[var(--color-accent)] disabled:opacity-70"
                />
                <button
                  type="submit"
                  disabled={!input.trim() || isSending}
                  className="p-3 rounded-lg bg-[var(--color-accent)] text-white disabled:bg-gray-500 hover:opacity-90 transition-opacity"
                >
                  {isSending ? <Loader2 size={24} className="animate-spin" /> : <Send size={24} />}
                </button>
              </form>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-[var(--color-text-secondary)]">
            <MessageSquare size={48} className="mb-4" />
            <h2 className="text-xl font-semibold">Select a conversation or start a new one</h2>
            <p className="text-sm">Your history with ELION OMEGA will appear here.</p>
          </div>
        )}
      </div>
    </div>
  );
}
