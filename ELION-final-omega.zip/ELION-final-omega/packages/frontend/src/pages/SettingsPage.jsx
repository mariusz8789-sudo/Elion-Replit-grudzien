// packages/frontend/src/pages/SettingsPage.jsx

import React from 'react';
import { Settings, Key, Database, Zap } from 'lucide-react';

export default function SettingsPage() {
  return (
    <div className="p-8 space-y-8">
      <header className="flex items-center space-x-4">
        <Settings className="w-10 h-10 text-gray-500" />
        <h1 className="text-3xl font-bold text-[var(--color-text-primary)]">System Settings</h1>
      </header>

      <p className="text-[var(--color-text-secondary)] max-w-3xl">
        Manage API keys, database connections, and core system configurations for ELION OMEGA.
      </p>

      <div className="space-y-6">
        {/* API Key Settings */}
        <section className="p-6 bg-[var(--color-bg-secondary)] rounded-lg shadow-lg border border-[var(--color-border)]">
          <div className="flex items-center space-x-3 mb-4">
            <Key className="w-6 h-6 text-[var(--color-accent)]" />
            <h2 className="text-xl font-semibold text-[var(--color-text-primary)]">API Keys</h2>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-1">OpenAI API Key</label>
              <input
                type="password"
                className="w-full p-2 border border-[var(--color-border)] rounded-lg bg-[var(--color-bg-primary)] text-[var(--color-text-primary)] focus:outline-none focus:border-[var(--color-accent)]"
                placeholder="sk-..."
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-1">Vercel API Token</label>
              <input
                type="password"
                className="w-full p-2 border border-[var(--color-border)] rounded-lg bg-[var(--color-bg-primary)] text-[var(--color-text-primary)] focus:outline-none focus:border-[var(--color-accent)]"
                placeholder="vsl_..."
              />
            </div>
          </div>
          <button className="mt-4 px-4 py-2 bg-[var(--color-accent)] text-white font-semibold rounded-lg hover:opacity-90 transition-opacity">
            Save API Settings
          </button>
        </section>

        {/* Database Settings */}
        <section className="p-6 bg-[var(--color-bg-secondary)] rounded-lg shadow-lg border border-[var(--color-border)]">
          <div className="flex items-center space-x-3 mb-4">
            <Database className="w-6 h-6 text-green-500" />
            <h2 className="text-xl font-semibold text-[var(--color-text-primary)]">Database Connection</h2>
          </div>
          <p className="text-[var(--color-text-secondary)] mb-4">
            Current connection status: <span className="text-green-500 font-bold">Connected (PostgreSQL)</span>
          </p>
          <button className="px-4 py-2 border border-[var(--color-border)] text-[var(--color-text-primary)] font-semibold rounded-lg hover:bg-[var(--color-bg-primary)] transition-colors">
            Run Migrations
          </button>
        </section>
      </div>
    </div>
  );
}
