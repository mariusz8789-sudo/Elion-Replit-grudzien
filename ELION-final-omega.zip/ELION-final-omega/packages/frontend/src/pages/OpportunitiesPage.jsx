// packages/frontend/src/pages/OpportunitiesPage.jsx

import React from 'react';
import { Lightbulb, TrendingUp, Zap } from 'lucide-react';

export default function OpportunitiesPage() {
  const opportunities = [
    {
      id: 1,
      title: "Refactor Legacy Authentication",
      description: "The current authentication system uses an outdated library. Refactoring to JWT with a modern framework will improve security and performance.",
      impact: "High Security, High Performance",
      cost: "Medium",
      status: "Recommended",
    },
    {
      id: 2,
      title: "Implement Dark Mode Toggle",
      description: "Add a user-friendly dark mode option to the frontend for better accessibility and user experience.",
      impact: "Medium UX, Low Effort",
      cost: "Low",
      status: "Quick Win",
    },
    {
      id: 3,
      title: "Optimize Database Queries",
      description: "Analyze slow queries in the chat history module and add necessary indexes to the PostgreSQL database.",
      impact: "High Performance, Medium Effort",
      cost: "Medium",
      status: "Critical",
    },
  ];

  return (
    <div className="p-8 space-y-8">
      <header className="flex items-center space-x-4">
        <Lightbulb className="w-10 h-10 text-yellow-500" />
        <h1 className="text-3xl font-bold text-[var(--color-text-primary)]">Development Opportunities</h1>
      </header>

      <p className="text-[var(--color-text-secondary)] max-w-3xl">
        ELION OMEGA has analyzed the codebase and system architecture to identify potential improvements, security enhancements, and quick wins. Select an opportunity to start an **AutoDev** task.
      </p>

      <div className="space-y-4">
        {opportunities.map((opp) => (
          <div key={opp.id} className="p-6 bg-[var(--color-bg-secondary)] rounded-lg shadow-lg border border-[var(--color-border)] flex justify-between items-center">
            <div>
              <h2 className="text-xl font-semibold text-[var(--color-text-primary)] mb-1">{opp.title}</h2>
              <p className="text-[var(--color-text-secondary)] mb-2">{opp.description}</p>
              <div className="flex space-x-4 text-sm">
                <span className="flex items-center text-green-500">
                  <TrendingUp className="w-4 h-4 mr-1" /> {opp.impact}
                </span>
                <span className="flex items-center text-blue-500">
                  <Zap className="w-4 h-4 mr-1" /> Cost: {opp.cost}
                </span>
              </div>
            </div>
            <button className="px-4 py-2 bg-[var(--color-accent)] text-white font-semibold rounded-lg hover:opacity-90 transition-opacity">
              Start AutoDev
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
