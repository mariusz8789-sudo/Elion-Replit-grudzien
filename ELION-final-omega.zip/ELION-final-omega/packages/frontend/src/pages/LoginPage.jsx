// packages/frontend/src/pages/LoginPage.jsx

import React, { useState } from 'react';
import { authApi } from '../lib/api';
import { useNavigate } from 'react-router-dom';

export default function LoginPage() {
  const [email, setEmail] = useState('admin@elion.com');
  const [password, setPassword] = useState('ElionOmega1');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const { data } = await authApi.login(email, password);
      localStorage.setItem('elion_token', data.token);
      navigate('/');
    } catch (err) {
      setError('Login failed. Check credentials.');
    }
  };

  return (
    <div className='flex items-center justify-center h-screen bg-gray-900'>
      <form onSubmit={handleSubmit} className='p-8 bg-gray-800 rounded-lg shadow-xl w-96'>
        <h1 className='text-2xl font-bold mb-6 text-center text-white'>ELION OMEGA Login</h1>
        {error && <p className='text-red-500 mb-4 text-center'>{error}</p>}
        <input
          type='email'
          placeholder='Email'
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className='w-full p-3 mb-4 border border-gray-700 rounded bg-gray-700 text-white'
          required
        />
        <input
          type='password'
          placeholder='Password'
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className='w-full p-3 mb-6 border border-gray-700 rounded bg-gray-700 text-white'
          required
        />
        <button
          type='submit'
          className='w-full p-3 bg-indigo-600 text-white font-bold rounded hover:bg-indigo-700'
        >
          Login
        </button>
        <p className='text-xs text-center mt-4 text-gray-400'>Demo: admin@elion.com / ElionOmega1</p>
      </form>
    </div>
  );
}
