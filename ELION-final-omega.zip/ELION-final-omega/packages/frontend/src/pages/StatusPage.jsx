// packages/frontend/src/pages/StatusPage.jsx

import React from 'react';

export default function StatusPage() {
  return (
    <div className="p-6 bg-gray-800 min-h-full">
      <h1 className="text-3xl font-bold text-white mb-6">System Status</h1>
      <div className="bg-gray-700 p-4 rounded-lg shadow-lg">
        <p className="text-lg text-green-400">All systems operational.</p>
        <p className="text-sm text-gray-400 mt-2">This page will eventually show real-time health checks for all backend services (LLM, DB, Agent, etc.).</p>
      </div>
    </div>
  );
}
