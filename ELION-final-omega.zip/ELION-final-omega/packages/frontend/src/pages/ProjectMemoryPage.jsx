// packages/frontend/src/pages/ProjectMemoryPage.jsx

import React from 'react';
import { Brain, FileText, Search } from 'lucide-react';

export default function ProjectMemoryPage() {
  const memoryEntries = [
    {
      id: 1,
      type: "Code Snippet",
      content: "const jwtSecret = process.env.JWT_SECRET || 'dev_secret';",
      source: "packages/backend/src/middleware/auth.ts",
    },
    {
      id: 2,
      type: "Architecture Decision",
      content: "Decision to use PostgreSQL with pgvector for RAG context storage due to its native vector support.",
      source: "System Log",
    },
    {
      id: 3,
      type: "User Input",
      content: "User asked to implement a dark mode toggle.",
      source: "Chat History",
    },
  ];

  return (
    <div className="p-8 space-y-8">
      <header className="flex items-center space-x-4">
        <Brain className="w-10 h-10 text-pink-500" />
        <h1 className="text-3xl font-bold text-[var(--color-text-primary)]">Project Memory (RAG)</h1>
      </header>

      <p className="text-[var(--color-text-secondary)] max-w-3xl">
        This is the knowledge base used by the **ElionAgent** for Retrieval-Augmented Generation (RAG). It includes code snippets, architectural decisions, and chat history.
      </p>

      <div className="flex space-x-4">
        <input
          type="text"
          className="flex-grow p-2 border border-[var(--color-border)] rounded-lg bg-[var(--color-bg-primary)] text-[var(--color-text-primary)] focus:outline-none focus:border-[var(--color-accent)]"
          placeholder="Search project memory..."
        />
        <button className="px-4 py-2 bg-[var(--color-accent)] text-white font-semibold rounded-lg hover:opacity-90 transition-opacity flex items-center">
          <Search className="w-5 h-5 mr-2" /> Search
        </button>
      </div>

      <div className="space-y-4">
        {memoryEntries.map((entry) => (
          <div key={entry.id} className="p-4 bg-[var(--color-bg-secondary)] rounded-lg shadow-lg border border-[var(--color-border)]">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-[var(--color-accent)]">{entry.type}</span>
              <span className="text-xs text-[var(--color-text-tertiary)]">{entry.source}</span>
            </div>
            <p className="text-[var(--color-text-primary)] font-mono text-sm whitespace-pre-wrap">{entry.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
