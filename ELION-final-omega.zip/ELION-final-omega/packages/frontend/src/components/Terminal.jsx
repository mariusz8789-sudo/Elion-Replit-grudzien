// packages/frontend/src/components/Terminal.jsx

import React, { useState, useEffect, useRef } from 'react';
import { Terminal as TerminalIcon, Loader2 } from 'lucide-react';
import { devopsApi } from '../lib/api'; // Assuming a central API client

// This component is designed to poll the status of a task (e.g., from DaveOps or AutoDev)
// and display the logs in real-time.

const fetchTaskStatus = async (taskId) => {
  // Determine the API endpoint based on the task ID prefix
  let endpoint;
  if (taskId.startsWith('autodev-task')) {
    endpoint = `/api/autodev/status/${taskId}`;
  } else if (taskId.startsWith('docker-deploy') || taskId.startsWith('vercel-deploy')) {
    endpoint = `/api/daveops/status/${taskId}`;
  } else {
    return { taskId, status: 'FAILED', progress: 100, summary: 'Unknown Task Type', logs: ['Error: Task ID prefix not recognized.'] };
  }

  try {
    const response = await devopsApi.getLogs(taskId);
    return response.data;
  } catch (error) {
    console.error(`Error fetching status for ${taskId}:`, error);
    return { taskId, status: 'FAILED', progress: 100, summary: 'API Error', logs: [`Error: Could not connect to backend status endpoint. ${error.message}`] };
  }
};

export default function Terminal({ taskId }) {
  const [taskStatus, setTaskStatus] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const logsEndRef = useRef(null);

  const scrollToBottom = () => {
    logsEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (!taskId) return;

    let intervalId;

    const pollStatus = async () => {
      setIsLoading(true);
      const status = await fetchTaskStatus(taskId);
      setTaskStatus(status);
      setIsLoading(false);

      // Stop polling if the task is completed or failed
      if (status.status === 'COMPLETED' || status.status === 'FAILED' || status.status === 'SUCCESS') {
        clearInterval(intervalId);
      }
    };

    // Initial fetch
    pollStatus();

    // Start polling interval
    intervalId = setInterval(pollStatus, 2000); // Poll every 2 seconds

    // Cleanup function
    return () => clearInterval(intervalId);
  }, [taskId]);

  useEffect(() => {
    scrollToBottom();
  }, [taskStatus?.logs.length]);

  if (!taskId) {
    return (
      <div className="bg-black text-green-400 p-4 h-64 overflow-y-auto font-mono text-sm rounded-lg border border-gray-700">
        <p>ELION OMEGA Terminal Ready.</p>
        <p>Awaiting task ID for log monitoring...</p>
      </div>
    );
  }

  const statusColor = {
    'PLANNING': 'text-yellow-500',
    'CODING': 'text-blue-400',
    'TESTING': 'text-purple-400',
    'RUNNING': 'text-blue-400',
    'PENDING': 'text-yellow-500',
    'SUCCESS': 'text-green-500',
    'COMPLETED': 'text-green-500',
    'FAILED': 'text-red-500',
  };

  return (
    <div className="bg-black text-green-400 p-4 h-96 overflow-y-auto font-mono text-sm rounded-lg border border-gray-700 flex flex-col">
      <div className="flex justify-between items-center border-b border-gray-700 pb-2 mb-2">
        <div className="flex items-center space-x-2">
          <TerminalIcon className="w-4 h-4" />
          <span className="font-bold">Task: {taskId}</span>
        </div>
        <div className={`flex items-center space-x-2 ${statusColor[taskStatus?.status || 'PENDING']}`}>
          {taskStatus?.status !== 'COMPLETED' && taskStatus?.status !== 'FAILED' && taskStatus?.status !== 'SUCCESS' && <Loader2 className="w-4 h-4 animate-spin" />}
          <span className="uppercase">{taskStatus?.status || 'PENDING'}</span>
          {taskStatus?.progress !== undefined && (
            <span className="text-gray-400">({taskStatus.progress}%)</span>
          )}
        </div>
      </div>
      
      <div className="flex-grow overflow-y-auto">
        {taskStatus?.logs.map((log, index) => (
          <p key={index} className="whitespace-pre-wrap">{log}</p>
        ))}
        <div ref={logsEndRef} />
      </div>
    </div>
  );
}
