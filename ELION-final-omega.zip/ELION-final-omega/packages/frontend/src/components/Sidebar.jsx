// packages/frontend/src/components/Sidebar.jsx

import React from 'react';
import { NavLink } from 'react-router-dom';
import { MessageSquare, Zap, HardHat, BookOpen, Settings } from 'lucide-react';

const navItems = [
  { to: '/chat', icon: MessageSquare, label: 'Chat' },
  { to: '/agi', icon: Zap, label: 'AGI Console' },
  { to: '/opportunities', icon: HardHat, label: 'Opportunities' },
  { to: '/lessons', icon: BookOpen, label: 'Lessons' },
  { to: '/settings', icon: Settings, label: 'Settings' },
];

export default function Sidebar() {
  return (
    <aside className='w-60 flex flex-col border-r border-gray-700 bg-gray-900 p-4'>
      <nav className='flex flex-col space-y-2'>
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              `flex items-center space-x-3 p-3 rounded-lg transition-colors ${isActive ? 'bg-indigo-600 text-white' : 'text-gray-300 hover:bg-gray-700'}`
            }
          >
            <item.icon size={20} />
            <span className='font-medium'>{item.label}</span>
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
