// packages/frontend/src/components/Header.jsx

import React from 'react';
import { useAuth } from '../hooks/useAuth';
import { LogOut } from 'lucide-react';

export default function Header() {
  const { logout } = useAuth();

  return (
    <header className="flex items-center justify-between p-4 bg-gray-900 border-b border-gray-700">
      <h1 className="text-xl font-bold text-indigo-400">ELION OMEGA</h1>
      <button
        onClick={logout}
        className="flex items-center space-x-2 text-red-400 hover:text-red-500 transition-colors"
      >
        <LogOut className="w-5 h-5" />
        <span>Logout</span>
      </button>
    </header>
  );
}
