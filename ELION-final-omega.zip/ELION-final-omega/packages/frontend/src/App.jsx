// packages/frontend/src/App.jsx

import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
// ThemeProvider and AuthProvider are imported in main.jsx
import Layout from './Layout';
import LoginPage from './pages/LoginPage';
import StatusPage from './pages/StatusPage';
import AgiPage from './pages/AgiPage';
import OpportunitiesPage from './pages/OpportunitiesPage';
import LessonsPage from './pages/LessonsPage';
import ChatHistoryPage from './pages/ChatHistoryPage';
import SettingsPage from './pages/SettingsPage'; // Assuming SettingsPage is also needed

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route element={<Layout />}>
        <Route path="/" element={<Navigate to="/chat" replace />} /> {/* Changed default to /chat */}
        <Route path="/status" element={<StatusPage />} />
        <Route path="/agi" element={<AgiPage />} />
        <Route path="/chat" element={<ChatHistoryPage />} />
        <Route path="/opportunities" element={<OpportunitiesPage />} />
        <Route path="/lessons" element={<LessonsPage />} />
        <Route path="/settings" element={<SettingsPage />} />
      </Route>
    </Routes>
  );
}
