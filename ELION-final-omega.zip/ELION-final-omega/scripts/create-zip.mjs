// /home/ubuntu/elion-omega/scripts/create-zip.mjs

import { exec } from 'child_process';
import { promisify } from 'util';
import { fileURLToPath } from 'url';
import path from 'path';

const execPromise = promisify(exec);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const outputZip = path.resolve(rootDir, 'elion-omega-fixed.zip');

async function createZip() {
  console.log(`Starting ZIP creation for ${rootDir}...`);
  try {
    // Navigate to the parent directory of the project
    const parentDir = path.dirname(rootDir);
    const projectName = path.basename(rootDir);

    // Command to create the zip file, excluding node_modules and the script itself
    const command = `cd ${parentDir} && zip -r ${outputZip} ${projectName} -x "*/node_modules/*" "${projectName}/scripts/create-zip.mjs"`;
    
    const { stdout, stderr } = await execPromise(command);
    
    if (stderr) {
      console.error('ZIP creation encountered errors:', stderr);
    }
    
    console.log('ZIP creation successful.');
    console.log(`Output file: ${outputZip}`);
    console.log(stdout);
    
    // Move the zip file to the project root for easy access
    await execPromise(`mv ${outputZip} ${rootDir}`);
    console.log('ZIP file moved to project root.');

  } catch (error) {
    console.error('Failed to create ZIP file:', error);
    process.exit(1);
  }
}

createZip();
